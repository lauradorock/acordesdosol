const carouselContainer = document.querySelector('.carousel-container');
const slides = document.querySelectorAll('.carousel-slide');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');
let currentIndex = 0;

function goToSlide(index) {
    if (index < 0) {
        currentIndex = slides.length - 1;
    } else if (index >= slides.length) {
        currentIndex = 0;
    }
    const translateX = -currentIndex * 100 + '%';
    carouselContainer.style.transform = `translateX(${translateX})`;
}

prevBtn.addEventListener('click', () => {
    currentIndex--;
    goToSlide(currentIndex);
});

nextBtn.addEventListener('click', () => {
    currentIndex++;
    goToSlide(currentIndex);
});

// Iniciar o carrossel na primeira imagem
goToSlide(currentIndex);
